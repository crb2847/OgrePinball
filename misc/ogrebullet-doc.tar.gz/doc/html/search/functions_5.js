var searchData=
[
  ['enableactivestate',['enableActiveState',['../classOgreBulletDynamics_1_1RigidBody.html#a544724547b5709a8c244b025ef25c1dd',1,'OgreBulletDynamics::RigidBody']]],
  ['enablespring',['enableSpring',['../classOgreBulletDynamics_1_1SixDofSpringConstraint.html#aedd044e0c5fd14bf11df2c64ec4d50e5',1,'OgreBulletDynamics::SixDofSpringConstraint']]]
];
